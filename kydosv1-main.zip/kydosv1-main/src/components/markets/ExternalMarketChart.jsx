import { requestStatus } from '@/lib/requestError';
import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import MarketCandleChart from '@/components/solana/MarketCandleChart';
import useMarketCandles from '@/hooks/useMarketCandles';
import { CANDLE_INTERVALS } from '@/lib/marketCandles';
import { ageLabel, formatPrice } from '@/lib/markets';

export default function ExternalMarketChart({ mint, symbol, livePrice }) {
  const [interval, setInterval] = useState('1h');
  const feed = useMarketCandles(mint, interval), { page, candles } = feed;
  const signIn = [401, 403].includes(requestStatus(feed.error));
  return <section aria-label={`${symbol} interactive price chart`} className="mb-5 min-w-0 overflow-hidden rounded-2xl border border-border bg-card/70">
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-4">
      <div><h2 className="text-sm font-semibold">{symbol} / USD <span className="ml-2 font-mono text-primary">{formatPrice(livePrice ?? candles.at(-1)?.close)}</span></h2><p className="mt-1 text-[11px] text-muted-foreground">{page ? `${page.pool.name} · ${ageLabel(page.fetchedAt, feed.now)}` : 'Sampled Jupiter price history'}</p></div>
      <div className="flex max-w-full flex-wrap items-center gap-2"><div aria-label="Candle interval" className="flex rounded-lg bg-background/70 p-1">{CANDLE_INTERVALS.map(item => <button key={item} type="button" aria-pressed={item === interval} onClick={() => setInterval(item)} className={`min-h-9 rounded-md px-2.5 text-xs ${interval === item ? 'bg-primary/15 text-primary' : 'text-muted-foreground hover:text-foreground'}`}>{item}</button>)}</div><button type="button" aria-label="Refresh chart" disabled={feed.isFetching} onClick={() => feed.refetch()} className="flex h-10 w-10 items-center justify-center rounded-lg border border-border disabled:opacity-40"><RefreshCw className={`h-3.5 w-3.5 ${feed.isFetching ? 'animate-spin' : ''}`}/></button></div>
    </header>
    {feed.stale && candles.length > 0 && <p role="status" className="border-b border-amber-400/20 bg-amber-400/5 px-4 py-2 text-xs text-amber-200">Chart updates are delayed. Showing saved candles. {page?.warning || feed.error?.message}</p>}
    {candles.length > 0 ? <MarketCandleChart candles={candles} timeframe={interval} seriesKey={`jupiter:${mint}:${interval}:USD`} livePrice={livePrice} currency="USD" volumeCurrency="USD" onLoadOlder={feed.loadOlder} canLoadOlder={feed.hasMore && !feed.loadingOlder && !feed.historyError}/> : <div className="flex min-h-[390px] flex-col items-center justify-center gap-3 px-6 text-center"><p role="status" className="text-sm text-muted-foreground">{feed.isPending && !feed.error ? 'Loading price history…' : feed.error?.message || 'Price history starts with new Jupiter samples. The first sample will appear after collection runs.'}</p>{signIn ? <Link to="/login" className="text-sm text-primary underline">Sign in</Link> : <button type="button" disabled={feed.isFetching} onClick={() => feed.refetch()} className="rounded-lg border border-border px-4 py-2 text-xs disabled:opacity-40">{feed.isFetching ? 'Loading…' : 'Retry chart'}</button>}</div>}
    <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-[11px] text-muted-foreground"><div><p>{page ? <><a href={`https://jup.ag/tokens/${mint}`} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2">Jupiter Price V3</a> · {candles.length} sampled candles · Volume unavailable</> : 'Data via Jupiter Price V3'}</p><p className="mt-1">One-minute price samples, not every trade; gaps are not filled. History grows from collection start. Drag to pan; scroll or pinch to zoom.</p>{feed.historyError && <p role="status" className="mt-2 text-amber-200">{feed.historyError}</p>}{feed.atHistoryLimit && <p className="mt-2">History limit reached for this view. Choose a wider interval to see further back.</p>}</div><button type="button" onClick={feed.loadOlder} disabled={!feed.hasMore || feed.loadingOlder} className="shrink-0 rounded-lg border border-border px-3 py-2 text-xs disabled:opacity-40">{feed.loadingOlder ? 'Loading older…' : 'Load older'}</button></footer>
  </section>;
}